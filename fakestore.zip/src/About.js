import React from 'react'
import Nav from './Nav'

function About() {
  return (
    <div>
        <Nav />
        About page
        </div>
  )
}

export default About