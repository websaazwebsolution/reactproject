import React from 'react'
import Nav from './Nav'

function Contact() {
  return (
    <div>
            <Nav />
        Contact page</div>
  )
}

export default Contact