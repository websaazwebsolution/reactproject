import React from 'react'

function Button() {
  return (
    <div>
        <button type="button" class="btn btn-primary">Appl Now</button>
    </div>
  )
}

export default Button