import React from 'react'

function Content() {
  return (
    <div>
        <p>lorem lorem voluptate officia corrupti accusamus</p>

    </div>
  )
}

export default Content